import { Button } from "@/components/ui/button";
import { ArrowDown } from "lucide-react";

const Hero = () => {
  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center pt-16"
      aria-label="Apresentação"
    >
      {/* Subtle background accent */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-32 -right-32 w-96 h-96 rounded-full bg-primary/5 blur-3xl" />
        <div className="absolute bottom-0 -left-32 w-80 h-80 rounded-full bg-accent/30 blur-3xl" />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col-reverse lg:flex-row items-center gap-12 lg:gap-20">
          {/* Text */}
          <div className="flex-1 text-center lg:text-left">
            <p className="text-sm font-semibold tracking-widest uppercase text-primary animate-fade-in">
              Lucas Santos de Almeida
            </p>
            <h1 className="mt-4 text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight text-foreground animate-fade-in-up">
              Apoio técnico e científico para profissionais da saúde
            </h1>
            <p className="mt-6 text-lg text-muted-foreground max-w-xl mx-auto lg:mx-0 animate-fade-in-delay">
              Análise de dados, revisão acadêmica, mentoria em farmacotécnica e muito mais — para quem está construindo carreira na área da saúde.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center lg:justify-start animate-fade-in-up-delay">
              <Button size="lg" asChild>
                <a href="#contato">Fale Comigo</a>
              </Button>
              <Button variant="outline" size="lg" asChild>
                <a href="#servicos">Conheça os Serviços</a>
              </Button>
            </div>
          </div>

          {/* Photo */}
          <div className="flex-shrink-0 animate-fade-in">
            <div className="relative">
              <div className="absolute -inset-4 rounded-full bg-primary/10 blur-2xl" />
              <img
                src="/lucas-profile.jpeg"
                alt="Foto de Lucas Santos de Almeida"
                width={320}
                height={320}
                className="relative w-64 h-64 sm:w-80 sm:h-80 rounded-full object-cover border-4 border-primary/20 shadow-xl"
                loading="eager"
              />
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce hidden lg:block">
          <a href="#sobre" aria-label="Rolar para baixo">
            <ArrowDown className="h-6 w-6 text-muted-foreground" />
          </a>
        </div>
      </div>
    </section>
  );
};

export default Hero;
