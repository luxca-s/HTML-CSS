import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";

const projects = [
  {
    image: "/project-1.png",
    title: "Análise Estatística em Pesquisa Clínica",
    description: "Tratamento e análise de dados para projeto de pesquisa na área farmacêutica, com visualizações e relatório completo.",
    tags: ["Estatística", "Farmácia", "Pesquisa"],
  },
  {
    image: "/project-2.png",
    title: "Revisão de Artigo Científico",
    description: "Revisão metodológica e gramatical de artigo científico para publicação em revista indexada.",
    tags: ["Revisão", "Artigo", "Publicação"],
  },
  {
    image: "/project-3.png",
    title: "Otimização de Perfil LinkedIn",
    description: "Reestruturação completa de perfil LinkedIn para profissional de enfermagem, aumentando visibilidade e conexões.",
    tags: ["LinkedIn", "Enfermagem", "Carreira"],
  },
];

const Projects = () => {
  return (
    <section id="projetos" className="py-20 lg:py-28" aria-labelledby="projetos-titulo">
      <div className="container mx-auto px-4">
        <h2 id="projetos-titulo" className="text-3xl sm:text-4xl font-bold text-foreground text-center">
          Projetos
        </h2>
        <p className="mt-4 text-muted-foreground text-center max-w-2xl mx-auto">
          Alguns exemplos de trabalhos realizados para profissionais e estudantes da saúde.
        </p>

        <div className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {projects.map((p) => (
            <Card
              key={p.title}
              className="overflow-hidden group hover:shadow-lg transition-shadow duration-300"
            >
              <div className="aspect-video overflow-hidden">
                <img
                  src={p.image}
                  alt={p.title}
                  loading="lazy"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="p-6">
                <h3 className="text-lg font-semibold text-foreground">{p.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{p.description}</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  {p.tags.map((tag) => (
                    <Badge key={tag} variant="secondary" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;
