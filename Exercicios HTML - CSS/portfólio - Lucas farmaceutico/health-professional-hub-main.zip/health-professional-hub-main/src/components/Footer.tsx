import { Linkedin } from "lucide-react";

const Footer = () => {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-border py-8" role="contentinfo">
      <div className="container mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
        <p>© {year} Lucas Santos de Almeida. Todos os direitos reservados.</p>
        <a
          href="https://linkedin.com/in/lucassantos"
          target="_blank"
          rel="noopener noreferrer"
          aria-label="LinkedIn de Lucas Santos"
          className="hover:text-primary transition-colors"
        >
          <Linkedin className="h-5 w-5" />
        </a>
      </div>
    </footer>
  );
};

export default Footer;
