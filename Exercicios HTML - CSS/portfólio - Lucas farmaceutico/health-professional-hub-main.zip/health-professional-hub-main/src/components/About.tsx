import { BarChart3, Linkedin, BookOpen, Search, FlaskConical } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const services = [
  {
    icon: BarChart3,
    title: "Análise de Dados e Consultoria Estatística",
    description: "Tratamento, análise e interpretação de dados com métodos estatísticos adequados para pesquisas na área da saúde.",
  },
  {
    icon: Linkedin,
    title: "Design de Perfil LinkedIn",
    description: "Otimização e organização do seu perfil LinkedIn, nichado para a área da saúde, para atrair oportunidades profissionais.",
  },
  {
    icon: BookOpen,
    title: "Revisão e Elaboração Acadêmica",
    description: "Desde trabalhos de faculdade até revisão de artigos científicos e TCCs, com rigor técnico e metodológico.",
  },
  {
    icon: Search,
    title: "Revisão de Literatura Técnico-Científica",
    description: "Revisão sistemática e narrativa de artigos e patentes, com foco em evidências científicas atualizadas.",
  },
  {
    icon: FlaskConical,
    title: "Mentoria em Farmacotécnica",
    description: "Orientação nos primeiros passos da farmacotécnica, do desenvolvimento galênico à produção de formas farmacêuticas.",
  },
];

const About = () => {
  return (
    <>
      {/* Sobre */}
      <section id="sobre" className="py-20 lg:py-28" aria-labelledby="sobre-titulo">
        <div className="container mx-auto px-4 max-w-3xl text-center">
          <h2 id="sobre-titulo" className="text-3xl sm:text-4xl font-bold text-foreground">
            Sobre Mim
          </h2>
          <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
            Sou farmacêutico com experiência em pesquisa e desenvolvimento, apaixonado por transformar dados em decisões e conhecimento em resultados. 
            Ofereço apoio técnico e científico personalizado para estudantes e profissionais que estão dando os primeiros passos na área da saúde.
          </p>
        </div>
      </section>

      {/* Serviços */}
      <section id="servicos" className="py-20 lg:py-28 bg-muted/40" aria-labelledby="servicos-titulo">
        <div className="container mx-auto px-4">
          <h2 id="servicos-titulo" className="text-3xl sm:text-4xl font-bold text-foreground text-center">
            Serviços
          </h2>
          <p className="mt-4 text-muted-foreground text-center max-w-2xl mx-auto">
            Soluções pensadas para quem precisa de apoio técnico e científico de qualidade.
          </p>

          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {services.map((s) => (
              <Card
                key={s.title}
                className="group hover:shadow-lg hover:border-primary/30 transition-all duration-300 bg-card"
              >
                <CardContent className="p-6 flex flex-col items-start gap-4">
                  <div className="p-3 rounded-lg bg-primary/10 text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                    <s.icon className="h-6 w-6" aria-hidden="true" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground">{s.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{s.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default About;
