

## Plano: Portfólio Lucas Santos de Almeida

### Visão Geral
Site de portfólio pessoal para venda de serviços a profissionais da saúde. Design moderno e minimalista, mobile-first.

### Paleta de Cores
- **Azul primário:** #3B82F6 | **Cinza escuro:** #545F66 | **Cinza médio:** #829399 | **Destaque claro:** #F5FDC6

### Estrutura (single-page)

**1. Navbar** — Fixa, navegação por âncoras (Sobre, Serviços, Projetos, Contato) + link LinkedIn

**2. Hero**
- Headline principal: **"Apoio técnico e científico para profissionais da saúde"**
- Nome "Lucas Santos de Almeida" como subtítulo
- CTA "Fale Comigo" (rola até Contato)
- Foto do usuário com tratamento visual
- Animações sutis de entrada

**3. Sobre** — Apresentação + cards dos 5 serviços (análise de dados, LinkedIn, trabalhos acadêmicos, revisão de literatura, mentoria farmacotécnica)

**4. Projetos** — Grid de cards com imagens enviadas e tags por área

**5. Contato** — Formulário (nome, email, mensagem) + botão WhatsApp + LinkedIn

**6. Footer** — Rodapé simples

### Arquivos a criar/editar
1. `src/index.css` — variáveis CSS com a paleta
2. `src/components/Navbar.tsx`
3. `src/components/Hero.tsx`
4. `src/components/About.tsx`
5. `src/components/Projects.tsx`
6. `src/components/Contact.tsx`
7. `src/components/Footer.tsx`
8. `src/pages/Index.tsx` — compor todas as seções
9. `index.html` — meta tags SEO
10. Copiar imagens do usuário para `public/`

### Técnico
- Mobile-first, breakpoints Tailwind (sm/md/lg)
- Acessibilidade: contraste, alt text, labels, navegação por teclado
- Performance: lazy loading nas imagens
- SEO: title, description, og tags

